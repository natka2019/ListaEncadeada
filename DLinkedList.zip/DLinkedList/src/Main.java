// trabalho feito por Natália Andrade e Carol Sales


import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        DLinkedList<Integer> listaduplaencadeada = new DLinkedList<>();
        System.out.println("Lista Duplamente encadeada!!");
        listaduplaencadeada.adiciona(3);
        System.out.println(listaduplaencadeada);
        listaduplaencadeada.adiciona(4);
        System.out.println(listaduplaencadeada);
        listaduplaencadeada.adiciona(5);
        System.out.println(listaduplaencadeada);

    }
}
