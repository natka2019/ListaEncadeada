import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


public class DLinkedList<T> {
    No[] dados = new No[10];
    No<T> base = null;
    No<T> topo = null;
    int tamanho = -1;

    public static class No<T> {
        No<T> anterior;
        T dado;
        No<T> proximo;


        public No(No<T> anterior, T valor, No<T> proximo) {
            this.anterior = anterior;
            this.dado = valor;
            this.proximo = proximo;
        }
    }

    public void adiciona(T valor) { //aqui add um valor no final da lista
        if (estaVazia()) {
                dados[0] = new No(null, valor, null);
                base = null;
                topo = null;
                tamanho = tamanho + 1;
                System.out.println("Valor incluido: " + valor);
        } else {
                tamanho = tamanho + 1;
                dados[tamanho] = new No(topo, valor, null);
                dados[tamanho - 1].proximo = dados[tamanho];
                topo = dados[tamanho];
                System.out.println("Valor incluido: " + valor);
            }
        }

    public void adiciona(int pos, T valor) { // aqui add um valor no meio da lista, pegando a posicao
        if (!estaCheia()) {
            for (int i = 0; i < dados.length; i++) {
                if (dados[i] == null) {
                    No no = getNo(pos);
                    if (no == base) {
                        dados[i] = new No(null, valor, no);
                        no.proximo = dados[i];
                        base = dados[i];
                    } else if (no == topo) {
                        dados[i] = new No(no.anterior, valor, no);
                        no.anterior.proximo = dados[i];
                        no.anterior = dados[i];
                    } else {
                        dados[i] = new No(no.anterior, valor, no);
                        no.anterior.proximo = dados[i];
                        no.proximo.anterior = dados[i];
                    }
                } else {
                    dados[i] = new No(topo, valor, null);
                    topo = dados[i];
                }
                System.out.println("Valor adicionado: " + valor);
                tamanho = tamanho + 1;
                break;
            }
        }
    }

    public T remove(int pos) {
        No no = getNo(pos);
        if (no != null) {
            if (no == topo) {
                no.anterior.proximo = null;
                topo = no.anterior;
            } else if (no == base) {
                no.proximo.anterior = null;
                base = no.proximo;
            } else {
                No proximoNo = no.proximo;
                No anteriorNo = no.anterior;
                anteriorNo.proximo = proximoNo;
                proximoNo.anterior = anteriorNo;
            }
            no.proximo = null;
            no.anterior = null;
            tamanho--;
        }
        System.out.println("Valor retirado" + no.dado);
        attLista();
        tamanho = tamanho - 1;
        return (T) no;
    }

    public T remove(T valor) {
        No no = base;
        while (no.proximo != null || no.anterior != null) {
            if (no != null && no.dado == valor) {
                if (no == topo) {
                    no.anterior.proximo = null;
                    topo = no.proximo;
                } else if (no == base) {
                    no.proximo.anterior = null;
                    base = no.proximo;
                } else {
                    No proximoNo = no.proximo;
                    No anteriorNo = no.anterior;
                    anteriorNo.proximo = proximoNo;
                    proximoNo.anterior = anteriorNo;
                }

                no.proximo = null;
                no.anterior = null;
                tamanho = tamanho - 1;
                break;
            }
            no = no.proximo;
        }
        System.out.println("Valor retirado " + no.dado);
        attLista();
        return (T) no;
    }

    public No<T> getNo(int pos){
        Objects.checkIndex(pos, tamanho);
        int meio = tamanho / 2; // aqui ele vai iterar e em seguida ver se a posição desejada é do meio pro final ou do meio pro começo

        //vai pra frente
        if (pos <= meio){
            No<T> atual = base;
            for (int i = 0; i < pos; i++) {
                atual = atual.proximo;
            }
            return atual;
        }
        //vai pra tras
        No<T> atual = topo;
        for (int i = tamanho-1; i != pos; i--) {
            atual = atual.anterior;
        }
        return atual;
    }

    public T get(int pos){ // get sempre ser do mesmo tipo, no caso, generics
        if(getNo(pos) != null) {
            return getNo(pos).dado;
        }
        return null;
    }

    public void set(int pos, T valor) {
        getNo(pos).dado = valor;
    }

    public boolean estaVazia() {
        return tamanho == -1;
    }

    public boolean estaCheia() {
        return false;
    }

    public int getTamanho() {
        return tamanho;
    }

    public void limpa(){ // aqui o garbage collector faz boa parte do trabalho
        base = null;
        topo = null;
        tamanho = 0;
    }

    public void attLista() {
        for (int i = 0; i < dados.length; i++) {
            if(dados[i] != topo && dados[i] != base && dados[i] != null) {
                if(dados[i].anterior == null || dados[i].proximo == null){
                    dados[i] = null;
                }
            }
        }
    }

    @Override // aqui ele possibilita imprimir a lista na main
    public String toString() {
        var text = "[ ";

        for (No <T> node = base; node != null; node = node.proximo) {
            text += node.dado + " ";
        }
        text += "]";
        return text;
    }
}
